
<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	
	<title>FORM</title>
</head>
<body>

<div id="auth__div">

<h1>Thank you</h1>
		
</div>
</body>
</html>