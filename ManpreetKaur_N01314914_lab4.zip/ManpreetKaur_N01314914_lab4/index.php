<!DOCTYPE html>
<html lang="en">

<head>
<title></title>

</head>
<body>

<?php
	
        include "header.php";
?>


<section>
<?php
       include "content1.php";
?>
</section>

<?php
include "footer.php";
?>


</body>
</html>