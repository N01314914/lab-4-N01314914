<?php
$nameErr ="";
$pswdErr="";
$phnErr="";
$emailErr="";
$radioErr="";
$chkBoxerr="";

$name = $email = $password = $phone = $gender = "" ;
$flag=false;
if(isset($_POST['email'])){
	
	
	$name= $_POST['name'];
	$password=$_POST['password'];
	$phone= $_POST['phone'];
	$email= $_POST['email'];
	if(isset($_POST['gender'])){
		$gender= $_POST['gender'];
	}
	


	if($name == "")
	{
		$nameErr = "Please enter your name</br>";
	}
	else {
		$nameErr = "";
	}

	$paswd_pattern= "/[a-zA-Z0-9]{6,8}/";
	 if($password == "")
	 {
		 $pswdErr="enter password";
	 }
	 elseif(!preg_match($paswd_pattern , $password))
	 {
		 $passErr="please enter valid password";
	 }
		else{$passErr = ""; }


	 $phone_pattern = "/[0-9]{9,10}/";  
	   if($phone == ""){
		   $phnErr="please enter phone";
	   }
	   elseif(!preg_match($phone_pattern , $phone)){
		   $phnErr="enter ten digit phone number"; 
	   }
	   else{
		   $phnErr = "";
	   }

	if($email == "")
	{ 
	$emailErr = "enter email";
	}
	elseif (!filter_input(INPUT_POST, 'email', FILTER_VALIDATE_EMAIL)){
		$emailErr = "please enter valid email address";
	}
	else{
		$emailErr = "";
	}
	
	if($gender == ""){
		$radioErr = "please select gender";
	}
	else{
		$radioErr = "";
	}


	if($nameErr == "" && $pswdErr == "" && $phnErr == "" && $emailErr == ""  && $radioErr =="" ){
		$flag = true;
	}
	if ($flag == true)
	{
		header ("location: thanku.php");
		exit();
	}

}
?>


<!DOCTYPE html>
<html lang="en">
<head>
	<meta charset="utf-8" />
	    <link rel="stylesheet" type="text/css" href="content.css">
	<title>FORM</title>
</head>
<body>
<div id="mainDiv">

<form action="" method="post">

<div id="auth__username">
<label>Username:</label>
<input type="text" id="auth__username_name" name="name" value="<?= $name; ?>"/><span><?php echo $nameErr; ?></span>
</div>

<div id="auth__pswd">
<label>Password:</label>
<input type="password" id="auth__password" name="password" value="<?= $password; ?>" /><span> <?php echo $pswdErr; ?></span>
</div>

<div id="auth__ph">
<label>Phone</label>
<input type="text" id="auth__phone" name="phone" value="<?=$phone; ?>" /><span> <?php echo $phnErr; ?></span>
</div>
<div id="auth__ph">
<label>Email</label>
<input type="text" id="auth__email" name="email" value="<?=$email;?>" /><span> <?php echo $emailErr; ?></span>
</div>
<div id="auth__radio">


<div id="radioBtn">
<p>Gender:
<?php
$genders = ['Male' => 'male', 'Female' => 'female', 'Other' => 'other'];
	 foreach($genders as $key => $value){
		 echo '<input type="radio" name = "gender" value = "' . $value . '" ';
		 if(isset($gender) && $gender == $value ){
			 echo 'checked />';
		 }
		 else{
			 echo " />";
		 }
		 
		    echo $key;
		  
	 }
?>
<span>
<?php
					if(isset($radioErr)){
						echo $radioErr;
					}
?>	
</span>				
</div>


<div id="message">
<label>Message</label>
<textarea rows="4" cols="30" value=""></textarea>
</div>


<button type="submit">submit</button>

</form>
</div>
</body>
</html>