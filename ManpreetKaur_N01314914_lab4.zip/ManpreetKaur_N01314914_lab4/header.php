<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <title>Penguin House</title>
    <link rel="stylesheet" type="text/css" href="header.css">
  </head>
  <body>
    <header id="header">
      <div class="page-wrapper">
        <div id="logo-and-slogan">
          <img id="logo" src="images/logo.png" alt="Penguin House logo">
          <h1 class="hidden">Penguin House</h1>
          <p id="slogan">A fun aquarium full of penguins</p>
        </div>
        </div>
        <nav id="main-menu">
          <h2 class="hidden">Main navigation</h2>
		  <?php
		  function main_navigation(){
		  $navigation = [
		  'home' => 'home.php',
		  'Penguins' => 'Penguins.php',
		  'Visit' => 'Visit.php',
		  'Buy Tickets' => 'Buy Tickets.php',
		  'Shop' => 'Shop.php',
		  'About' => 'About.php',
		  'FAQ' => 'FAQ.php'
		  ];

		   foreach($navigation as $key => $value){
			echo   $key . " | " ;
			}
		  }
		     main_navigation();
		  ?>
		  
          <!--<ul>
            <li><a href="index.html">Home</a></li>
            <li><a href="#">Penguins</a></li>
            <li><a href="#">Visit</a></li>
            <li><a href="#">Buy Tickets</a></li>
            <li><a href="#">Shop</a></li>
            <li><a href="#">About</a></li>
            <li><a href="#">FAQ</a></li>
          </ul>-->
        </nav>
      </div><!--end page-wrapper-->
    </header>
    
     </main>
    </div>
  </body>
</html>















