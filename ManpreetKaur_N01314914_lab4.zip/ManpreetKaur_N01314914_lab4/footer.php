<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8"/>
  <title>Mockup assignment</title>
  <link rel="stylesheet" type="text/css" href="footer.css" />
</head>
<body>
<div>
<footer id="footer">
	<div>

		<nav id="main2-navigation">
		<?php
		
		  main_navigation();
		  
		 ?>
			<!--<ul class="menu2">
			  <li>Home</li>
			  <li>Penguine</li>
			  <li>Visit</li>
			  <li>Buy Tickets </li>
			  <li>Shop</li>
			  <li>About</li>
			  <li>FAQ</li>
			</ul>-->
		 </nav>
	</div>
	<div id="copy_right">
	  <p>&copy;Copy right Assignment2(Mockup),2018</p>
	</div>
	</footer>
	</div>
  </body>
  </html>